
import java.util.StringTokenizer;

public class Postfix {
    public static boolean isOperator(char c) {
        return ((c == '+') || (c == '-') || (c == '*') || (c == '/'));
    }
    
    public static boolean isWhitespace(char c) {
        return ((c == ' ') || (c == '\n') || (c == '\t') || (c == '\r'));
    }

    public static ExpressionTree buildTree(String postfix){
    	StringTokenizer parser = new StringTokenizer(postfix, " \n\t\r+-*/", true);
    	Stack s = new Stack();
    	Stack a = new Stack(); 
    	while(parser.hasMoreTokens()){
    		String token = parser.nextToken();
    		TreeNode b = new TreeNode(token);
    		if(!isWhitespace(token.charAt(0))){
    			s.push(b);
    		}
    	}
    	ExpressionTree tree = new ExpressionTree();
    	tree.root = s.pop();
    	a.push(tree.root);
    	TreeNode pointer = tree.root;
    	while(!s.isEmpty()){
    		if(isOperator(pointer.data.charAt(0))){
    			a.push(pointer);
    			pointer.right = s.pop();
    			pointer = pointer.right;
    		}
    		else{
    			pointer = a.pop();
    			pointer.left = s.pop();
    			pointer = pointer.left;
    		}
    	}
    	return tree;
    }
        
    public static void main(String[] args) {
    	ExpressionTree tree = buildTree("5 2 1 - - 6 5 / +");
    	//ExpressionTree tree = buildTree("5 31 1 + 2222 / - 6 5 / +");
    	System.out.print("Inorder:");
    	tree.inorder();
    	System.out.print("Postorder:");
    	tree.postorder();
		System.out.print("The size of the tree is: ");
    	System.out.println(tree.size());
		System.out.print("The size of the tree is: ");
    	System.out.println(tree.recSize());
    	// (((5)-((2)-(1)))+((6)/(5)))
    	// ((5-(2-1))+(6/5))
    	// 5-(2-1) + 6/5
    }
}
