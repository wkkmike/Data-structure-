class TreeNode{
	TreeNode left;
	TreeNode right;
	String data;
	public TreeNode(String data){
		this.data = data;
	}
    public String toString() {
        return data;
    }
}

public class ExpressionTree {
    public TreeNode root;
    public void inorder() {
    	String s = inorder(root);
    	System.out.println(s);
    }
    
    public String inorder(TreeNode r) {
    	if(r.left == null) return r.data;
    	return "(" + inorder(r.left) + r.data + inorder(r.right) + ")";
    }
    /*
    public void inoqrder(TreeNode r) {
    	Stack a = new Stack();
    	int lc = 0;
    	int rc = 0;
    	boolean flag = false;
    	TreeNode pointer = r;
    	TreeNode tem = null;
    	while(true){
    		while(pointer.left != null){
    			if(tem != null){
    				if((tem.data == "/") || ((tem.data == "*" || tem.data == "-") && (pointer.data == "+" || pointer.data == "-")))
    	    			rc++;
    				tem = null;
    			}
    			else if(!a.isEmpty()){
    				TreeNode temp = a.pop();
    				if((temp.data == "*" || temp.data == "/") && (pointer.data == "+" || pointer.data == "-"))
    					lc++;
    				a.push(temp);
    			}
    			a.push(pointer);
    			pointer = pointer.left;
    		}
    		for(int i=0; i < lc; i++){
    			System.out.print("(");
    		}
    		if(flag) flag = false;
    		else System.out.print(pointer.data);
    		if(a.isEmpty()) break;
    		pointer = a.pop();
    		tem = pointer;
    		System.out.print(pointer.data);
    		TreeNode temp = pointer;
    		pointer = pointer.right;
    		if((temp.data == "/") || ((temp.data == "*" || temp.data == "-") && (pointer.data == "+" || pointer.data == "-")))
    			rc++;
    		if(pointer.right == null){
    			System.out.print(pointer.data);
    			flag = true;
    			for(int i = 0; i<= (rc - lc);i++) System.out.print(")");
    			rc = rc - lc;
    		}
    		
    		lc = 0;
    	}
    	System.out.println(" ");
    }*/

    public void preorder() {
    	preorder(root);
    }
    public void preorder(TreeNode r) {
    	Stack s = new Stack();
    	TreeNode pointer = r;
    	while(true){
    		System.out.print(pointer.data + " ");
    		if(pointer.right != null){
    			s.push(pointer);
    			pointer = pointer.left;
    		}
    		else{
    			if(s.isEmpty())break;
    			pointer = s.pop();
    			pointer = pointer.right;
    		}
    	}
    	System.out.println(" ");
    }

    public void postorder() {
    	String s = postorder(root);
    	System.out.println(s);
    }
    public String postorder(TreeNode r) {
    	if(r.left == null) return r.data;
    	else return postorder(r.left) + " " + postorder(r.right) + " " + r.data;
    }
    
    public int size() { 
    	Stack a = new Stack();
    	int count = 0;
    	TreeNode pointer = root;
    	while(true){
    		while(pointer.left != null){
    			a.push(pointer);
    			pointer = pointer.left;
    			count++;
    		}
    		
    		count++;
    		if(a.isEmpty()) break;
    		pointer = a.pop();
    		pointer = pointer.right;
    	}
    	return count;
    }
    
    public int recSize() { return recSize(root); } 
    public int recSize(TreeNode node) {
    	if(node.left == null && node.right == null) return 1;
    	return recSize(node.left) + recSize(node.right) + 1;
    }
}
