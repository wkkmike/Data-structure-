import java.util.*;
import java.security.SecureRandom;
import java.util.stream.Collectors;

public class HoareQuickSort{
    public static void swap(int[] a, int x, int y) {
    	int temp = a[x];
    	a[x] = a[y];
    	a[y] = temp;
    }
    
	public static void hoare(int[] a, int begin, int end) {
    	//
    	if(begin >= end)return;
    	int pivot = a[end];
    	int l = begin;
    	int r = end-1;
    	while(l < r){
    		while(a[l] < pivot && l < r) l++;
    	
    		while(a[r] >= pivot && l < r)r--;
    		
    		swap(a, l, r);
    	}
    	if(a[l] > pivot) swap(a,l,end);
    	else{
    		l++;
    	}
    	hoare(a, begin, l-1);
    	hoare(a,l+1 , end);
    }
    
    public static void main(String args[]){
    	int[] a={3,5,1,7,4,9,10,34,67,6,8,19};
    	System.out.print("Before sort:");
    	System.out.println(Arrays.toString(a));
    	hoare(a,0,a.length-1);
    	System.out.print("After sort:");
    	System.out.println(Arrays.toString(a));
    }
}
