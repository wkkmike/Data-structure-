/**
 * Created by michael on 2016/12/6.
 */
public class GraphBoth {
    private int order;  // the number of vertices
    private List[] aLists;
    private boolean[][] aMatrix;

    public GraphBoth(int order) {
        this.order = order;
        aLists = new List[order];
        for (int i = 0; i < order; i++)
            aLists[i] = new List();
        aMatrix = new boolean[order][order];
    }

    public GraphBoth(boolean[][] aMatrix) {
        order = aMatrix.length;
        // check the matrix is a square and symmetric
        this.aMatrix = aMatrix;
        for(int i=0;i<order;i++){
            for(int j = i+1;j<order;j++){
                if(aMatrix[i][j]) addEdge(i, j);
            }
        }
    }

    public void addEdge(int a, int b) {
        // usually we don't allow self-loop
        // i.e., an edge with both ends on the same vertex
        if (a == b) return;
        aLists[a].insertAtFront(b);
        aLists[b].insertAtFront(a);
        aMatrix[a][b] = aMatrix[b][a] = true;
    }

    public void delete(int a, int b){
        if(!aMatrix[a][b]){
            System.out.println("No such edge");
            return;
        }
        aMatrix[a][b] = false;
        aMatrix[b][a] = false;
        aLists[a].delete(b);
        aLists[b].delete(a);
    }

    public boolean isAdjacent(int a, int b) {
        return aMatrix[a][b];
    }

    public int degree(int a) {
        return aLists[a].length();
    }

    public GraphBoth reduce(GraphBoth g){
        int delete = 0;
        int solution = 0;
        boolean flag = true;
        while(flag) {
            flag = false;
            for (int i = 0; i < g.order; i++) {
                if (g.degree(i) == 2) {
                    Node head = g.aLists[i].getHead();
                    int n1 = g.aLists[i].getHead().data;
                    int n2 = head.next.data;
                    if (isAdjacent(n1, n2)) {
                        g.delete(n1, i);
                        g.delete(n2, i);
                        Node h1 = aLists[n1].getHead();
                        Node h2 = aLists[n2].getHead();
                        while (h1 != null) {
                            g.delete(n1, h1.data);
                        }
                        while (h2 != null) {
                            g.delete(n2, h2.data);
                        }
                        delete++;
                        solution += 2;
                        return reduce(g);
                    } else {

                    }
                    flag = true;
                }
                else if(g.degree(i) == 1){
                    int n = g.aLists[i].getHead().data;
                    g.delete(n, i);
                    delete++;
                    solution++;
                    Node h = aLists[n].getHead();
                    while(h != null){
                        g.delete(n, h.data);
                    }
                    flag = true;
                }
                else if(g.degree(i) == 0){
                    delete++;
                    flag = true;
                }
            }
        }
        return g;
    }
}
